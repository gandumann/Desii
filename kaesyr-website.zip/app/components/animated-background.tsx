'use client'

export function AnimatedBackground() {
  return (
    <div className="fixed inset-0 z-0">
      <div className="absolute inset-0 bg-black">
        <div className="absolute inset-0 bg-gradient-to-br from-purple-900 via-black to-purple-900 animate-gradient-shift">
          <div className="absolute inset-0 opacity-50">
            <div className="absolute w-96 h-96 bg-purple-600/30 rounded-full filter blur-3xl animate-blob1"></div>
            <div className="absolute w-96 h-96 bg-purple-900/30 rounded-full filter blur-3xl animate-blob2"></div>
            <div className="absolute w-96 h-96 bg-violet-600/30 rounded-full filter blur-3xl animate-blob3"></div>
          </div>
        </div>
      </div>
    </div>
  )
}

