'use client'

import { Button } from "@/components/ui/button"
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { DiscIcon as Discord } from 'lucide-react'
import Image from "next/image"
import Link from "next/link"
import { useEffect, useState } from "react"

export function Navigation() {
  const [scrolled, setScrolled] = useState(false)

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 50)
    }
    window.addEventListener('scroll', handleScroll)
    return () => window.removeEventListener('scroll', handleScroll)
  }, [])

  return (
    <nav className={`fixed top-0 w-full z-50 transition-all duration-300 ${
      scrolled ? 'bg-black/80 backdrop-blur-sm' : 'bg-transparent'
    }`}>
      <div className="container mx-auto px-4">
        <div className="flex flex-col md:flex-row items-center justify-between h-auto md:h-16 py-4 md:py-0">
          <Link href="/" className="flex items-center gap-2 mb-4 md:mb-0">
            <Image
              src="https://cdn.discordapp.com/attachments/1327163566419087432/1327179613973250058/ccfbd7dedea89e4f0cbe66d69107aab7.webp?ex=67821fd5&is=6780ce55&hm=b391ccb98b9130c0f9d47cf08390b009caf15d03fcebb65c9cc4c38dd3ec485f"
              alt="Kaesyr Labs Logo"
              width={32}
              height={32}
              className="rounded-full"
            />
            <span className="font-bold text-xl text-purple-200">Kaesyr Labs</span>
          </Link>
          
          <div className="flex flex-col md:flex-row items-center gap-4">
            <Tabs defaultValue="features">
              <TabsList className="bg-purple-950/50 h-auto">
                <TabsTrigger value="features" className="px-2 py-1 text-sm">Features</TabsTrigger>
                <TabsTrigger value="plans" className="px-2 py-1 text-sm">Plans</TabsTrigger>
                <TabsTrigger value="contact" className="px-2 py-1 text-sm">Contact</TabsTrigger>
              </TabsList>
            </Tabs>
            
            <Button 
              className="bg-purple-600 hover:bg-purple-700 w-full md:w-auto"
              onClick={() => window.open('https://discord.gg/eyceXmmUs9', '_blank')}
            >
              <Discord className="w-5 h-5 mr-2" />
              Join Discord
            </Button>
          </div>
        </div>
      </div>
    </nav>
  )
}

