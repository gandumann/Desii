'use client'

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Cpu, HardDrive, MemoryStickIcon as Ram } from 'lucide-react'
import { motion } from "framer-motion"

interface PricingCardProps {
  name: string
  price: string
  specs: {
    ram: string
    storage: string
    cpu: string
  }
}

export function PricingCard({ name, price, specs }: PricingCardProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      viewport={{ once: true }}
    >
      <Card className="bg-purple-950/50 border-purple-800 hover:border-purple-600 transition-all duration-300">
        <CardHeader>
          <CardTitle className="text-2xl font-bold text-purple-200">{name}</CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="text-center">
            <span className="text-4xl font-bold text-purple-300">${price}</span>
            <span className="text-purple-400">/month</span>
          </div>
          
          <div className="space-y-4">
            <div className="flex items-center gap-2 text-purple-200">
              <Ram className="w-5 h-5 text-purple-400" />
              <span>{specs.ram}</span>
            </div>
            <div className="flex items-center gap-2 text-purple-200">
              <HardDrive className="w-5 h-5 text-purple-400" />
              <span>{specs.storage}</span>
            </div>
            <div className="flex items-center gap-2 text-purple-200">
              <Cpu className="w-5 h-5 text-purple-400" />
              <span>{specs.cpu}</span>
            </div>
          </div>

          <Button className="w-full bg-purple-600 hover:bg-purple-700">
            Select Plan
          </Button>
        </CardContent>
      </Card>
    </motion.div>
  )
}

