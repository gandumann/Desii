'use client'

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { motion } from "framer-motion"

export function ReferralProgram() {
  const rewards = [
    { invites: 2, ram: "2GB" },
    { invites: 4, ram: "4GB" },
    { invites: 6, ram: "6GB" },
    { invites: 8, ram: "8GB" },
  ]

  return (
    <section className="container mx-auto px-4 py-12">
      <h2 className="text-3xl md:text-4xl font-bold text-center mb-12 bg-clip-text text-transparent bg-gradient-to-r from-purple-400 to-purple-200">
        Free VPS Event
      </h2>
      <motion.div
        initial={{ opacity: 0 }}
        whileInView={{ opacity: 1 }}
        transition={{ duration: 0.5 }}
        viewport={{ once: true }}
      >
        <Card className="bg-purple-900/30 border-purple-800">
          <CardHeader className="text-center">
            <CardTitle className="text-3xl font-bold text-purple-200">
              🎉 Invite Friends, Get Free VPS!
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-8">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
              {rewards.map((reward) => (
                <motion.div
                  key={reward.invites}
                  whileHover={{ scale: 1.05 }}
                  className="bg-purple-950/50 p-6 rounded-lg text-center"
                >
                  <div className="text-xl font-bold text-purple-300 mb-2">
                    {reward.invites} Invites
                  </div>
                  <div className="text-purple-200">
                    {reward.ram} RAM VPS
                    <div className="text-sm text-purple-400">(24/7 docker)</div>
                  </div>
                </motion.div>
              ))}
            </div>

            <div className="space-y-4 text-center">
              <h3 className="text-xl font-bold text-purple-200">How to Participate:</h3>
              <ul className="text-purple-300 space-y-2">
                <li>• Invite friends to join our Discord server</li>
                <li>• Redeem your free VPS once you reach the invite milestone</li>
              </ul>
            </div>

            <div className="space-y-2 text-center text-sm text-purple-400">
              <p>* Limited time offer</p>
              <p>* Terms and conditions apply</p>
            </div>
          </CardContent>
        </Card>
      </motion.div>
    </section>
  )
}

